-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 192.168.1.220    Database: discord_afeka
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `cid` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `time` timestamp NOT NULL,
  `message` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`cid`,`username`,`time`),
  KEY `username` (`username`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`username`),
  CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`cid`) REFERENCES `chats` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'liran','2022-02-09 18:42:24','hhh'),(2,'amitbarel','2022-02-09 18:43:18','jj'),(2,'daniel','2022-02-09 18:42:48','f'),(2,'daniel','2022-02-09 20:21:35','dd'),(2,'daniel','2022-02-09 20:53:22','d'),(2,'liran','2022-02-09 18:42:56','k'),(2,'liran','2022-02-09 20:14:54','a'),(2,'liran','2022-02-09 20:23:31','dd'),(2,'liran','2022-02-09 20:53:25','s'),(2,'liran','2022-02-09 20:53:30','asd'),(2,'morePen','2022-02-09 20:54:09','asd'),(33,'liran','2022-02-09 19:56:18','d'),(907,'daniel','2022-02-09 20:21:54','d'),(907,'liran','2022-02-09 20:22:06','d'),(907,'liran','2022-02-09 20:23:23','d'),(908,'liran','2022-02-09 20:23:43','d'),(908,'morePen','2022-02-09 20:23:57','d');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-09 22:58:46
